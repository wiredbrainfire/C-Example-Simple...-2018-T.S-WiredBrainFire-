using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LetsMakeAnExamplexD
{
    public class Program_01 // a public class "non private" "non restricted nor protected"....
    {
        static void Main(string[] args) 
            /* this is not the first thing to explain i guess so lets leave it...! learn programming! if you want to its the same as building skyscrapers and stuff like that 
             * WiredBrainFire T.S 2018 Example - Visual Studio Community Preview 2017 - It's free so get it
             * 
             * Simple facts by the way!
             * int.. Integer ---> and is a whole number.
             * double.. is a double float precision point number 
             * float.. is a float precision point number 
             * char.. is a well.. "isn't it obvious a character like 'a' . Well ofcourse it is...
             * string.. is basically a word... assigned to something. And I am not a teacher so all misstakes written in this text if any are not accounted for..!
             * You got a lot more ofcourse...
             */
        {
            Console.WriteLine("Hello World!.. C-sharp, C# or C-Hashtag if you like to call it that..."); // cw + tab two times fast and you get it without the ""  <<----- also the one under --> 
            // is a comment as in single comment <<--- Lets make a hello world!

            /* Multiple comments on different lines okay? right! get it ?
             * See
             * this
             * works
             * perfectly 
             * ait! perfect...
             * end it now
             * worked ->>> look under how i did..!
             */



            Console.ReadKey(); // ----> next function pressed by user basically <----
        }
    }
}
